//
//  ViewController.swift
//  RandomNumber
//
//  Created by MacStudent on 2018-06-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    
    @IBOutlet weak var randomNumberLabel: UILabel!
    @IBOutlet weak var dateandtimeLabel: UILabel!
    
    let today: Date = Date()
    var tomorrow: Date = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        dateandtimeLabel.text = "\(today)"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func generateAction(_ sender: Any) {
        let generated = (arc4random() % 100)+1
        randomNumberLabel.text = "\(generated)"
    }
    
    
    @IBAction func seedAction(_ sender: Any) {
        srandom(CUnsignedInt(time(nil)))
        randomNumberLabel.text = "Generator Seeded"
    }
    
    @IBAction func nextDate(_ sender: Any) {
        // Sale Date = Tomorrow
        let timeToAdd: TimeInterval = 60*60*24
        tomorrow = today.addingTimeInterval(timeToAdd)
        dateandtimeLabel.text = "\(tomorrow)"
        
    }
}

